# Supplied predictions diagnostic

Model: gpt-4o-2024-08-06
Returned jobs: 72/72; invalid outputs: 0.
Decision: **supplied_predictions_near_ceiling_stop_shipping_task**

| Condition | Diagnostic / planned | Valid | Missing | Extra text |
| --- | ---: | ---: | ---: | ---: |
| rules_only | 4/24 | 24 | 0 | 0 |
| predictions_supplied | 24/24 | 24 | 0 | 0 |

Primary comparison: supplied predictions minus rules only.
Valid pairs: 24; difference (percentage points): 83.33333333333334; gains/losses: 20/0.
Descriptive 95% paired bootstrap interval: [66.66666666666666, 95.83333333333334].
Descriptive case bootstrap; repeated cases share one task template.

Initial hypotheses by rule: {"price": 24, "weight": 0}

Inspect audit.csv and the supplied_prediction_failures entries in analysis.json.
Read the raw requests and answers before interpreting any residual errors.

## Interpretation limits

- Twenty-four paired numerical cases from one task family; broad generalization is untested.
- The initial response is shared verbatim, but latent beliefs and confidence are not measured.
- The table changes visibility, redundancy, and presentation; a benefit does not uniquely identify an internal bottleneck.
- A supplied correct table does not prove the model read, trusted, or represented it correctly.
- Answer-only output does not establish absence of internal reasoning.
- Invalid and missing choices are not observed zero-information actions.
- The primary comparison uses valid pairs; all-planned rates and missingness are also reported.
- The answer-only subset and direction slices are secondary descriptive checks.
- Bootstrap intervals are descriptive; the exact paired p-value is exploratory.
- This study does not execute a test, sample a hidden rule, or measure final rule identification.
- The decision labels are planning heuristics, not significance, mechanism, or novelty verdicts.
