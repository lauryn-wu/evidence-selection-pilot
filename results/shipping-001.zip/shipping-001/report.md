# Evidence selection pilot

Model: gpt-4o-2024-08-06
Returned jobs: 144/144; invalid outputs: 24.
Decision: **measurement_issue_review_invalid_outputs**

| Condition | Diagnostic / planned | Valid | Missing | Text before choice | Median words |
| --- | ---: | ---: | ---: | ---: | ---: |
| direct | 7/24 | 24 | 0 | 0 | 0.0 |
| facts | 8/24 | 24 | 0 | 24 | 92.0 |
| deliberate | 20/24 | 24 | 0 | 24 | 102.0 |
| explain | 11/24 | 24 | 0 | 24 | 106.0 |

## Paired comparisons

Negative differences mean fewer diagnostic choices in the first condition.
The primary comparison is deliberate minus facts; the others are secondary.

| Comparison | Pairs | Difference (pp) | Descriptive bootstrap interval | Gains / losses |
| --- | ---: | ---: | --- | ---: |
| deliberate_minus_facts | 24 | 50.0 | [25.0, 70.8] | 13 / 1 |
| deliberate_minus_direct | 24 | 54.2 | [29.2, 75.0] | 14 / 1 |
| explain_minus_facts | 24 | 12.5 | [-4.2, 29.2] | 4 / 1 |
| explain_minus_deliberate | 24 | -37.5 | [-58.3, -16.7] | 1 / 10 |

Constant paired differences do not receive a zero-width interval. A null pilot does not establish equivalence.

Separate competence check: 0/24 cases with all six predicted fees correct.

## Interpretation limits

- The experimental unit is a paired generated case, not a response or prediction cell.
- All cases are numerical and order variants of one task; generalization is untested.
- Intervals are descriptive and p-values exploratory, unadjusted across contrasts.
- Equal observable prefixes do not establish equal latent beliefs or confidence.
- The intervention combines instructions with generated text; internal mechanism is untested.
- A competence call shows separate-task performance, not knowledge in a selection trace.
- This stage does not execute chosen tests or measure subsequent correction.
- Prefix length is an automatic format check, not a semantic audit of reasoning.
- Missing and invalid choices are failures to yield a diagnostic selection, not observed 0-bit actions.

Inspect audit.csv and attempts/*.json before interpreting the screen.
The decision rule is a planning heuristic for a small pilot, not a publication or novelty verdict.
The complete numerical output and exploratory exact paired p-values are in analysis.json.
